def calcul(n) :
	u = 0
	for i in range(n) :
		u = 3*u + 1
	return u
